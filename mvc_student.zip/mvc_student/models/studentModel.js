let students = [];

const getStudents = () => students;

const addStudent = (student) => {
    students.push(student);
};

module.exports = { getStudents, addStudent };